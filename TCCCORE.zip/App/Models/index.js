require("./Appointment")
require("./MedicalHistory")
require("./User")
require("./UserCategory")